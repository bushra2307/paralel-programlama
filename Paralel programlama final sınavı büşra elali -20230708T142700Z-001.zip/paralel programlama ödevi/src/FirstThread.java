import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
//Aşağıdaki kod bloğu, kullanıcının bilgilerini almak için birinci thread’i göstermektedir.
// FirstThread sınıfı Runnable arayüzünü uygular ve kullanıcıdan üç farklı veri alır. Veriler daha sonra txt dosyasına kaydedilir.
public class FirstThread implements Runnable {
    @Override
    public void run() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Kullanıcı adınızı girin: ");
        String username = scanner.nextLine();
        System.out.print("Şifrenizi girin: ");
        String password = scanner.nextLine();
        System.out.print("E-posta adresinizi girin: ");
        String email = scanner.nextLine();

        try {
            FileWriter writer = new FileWriter("C:\\\\\\\\Users\\\\\\\\berktug\\\\\\\\Desktop\\\\\\\\deneme.txt");
            writer.write(username + "\n");
            writer.write(password + "\n");
            writer.write(email + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
