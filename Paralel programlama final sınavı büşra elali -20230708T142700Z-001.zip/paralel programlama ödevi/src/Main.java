// Main sınıfı iki thread’i oluşturur ve ardından birinci thread’i başlatır.
// Birinci thread’in işlemi bittikten sonra ikinci thread başlatılır.

public class Main {
    public static void main(String[] args) throws InterruptedException {
        FirstThread firstThread = new FirstThread();
        SecondThread secondThread = new SecondThread();

        Thread t1 = new Thread(firstThread);
        Thread t2 = new Thread(secondThread);

        t1.start();
        t1.join();
        t2.start();
        t2.join();
    }
}
