import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

//  örnekte, SecondThread sınıfı Runnable arayüzünü uygular, kullanıcıdan veri alır. Veri daha sonra txt dosyasına  kaydedilir.
public class SecondThread implements Runnable {
    @Override
    public void run() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("secretInformation giriniz:");
        String input = scanner.nextLine();
        File file = new File("C:\\\\\\\\Users\\\\\\\\berktug\\\\\\\\Desktop\\\\\\\\deneme2.txt");
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(input);
            writer.close();
            System.out.println("Dosyaya yazıldı.");
        } catch (IOException e) {
            System.out.println("Dosyaya yazılırken bir hata oluştu.");
            e.printStackTrace();
        }
    }
}
